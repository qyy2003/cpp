#include<cstdio>
#include<iostream>
#include<cstring>
#include<vector>
#include<algorithm>
using namespace std;
const int MAXA=4000;
int n,m,x,y,last,fa[MAXA],deep[MAXA],a[MAXA],b[MAXA],mina,maxa;
int nxt[MAXA],first[MAXA<<1],go[MAXA<<1],tot;
long long ans,P=19260817,anss;
vector<pair<int,int> >q;
int add(int x,int y){
    nxt[++tot]=first[x]; first[x]=tot; go[tot]=y;
}
int lca(int x,int y){
    while(deep[x]>deep[y]) {
	if(a[x]>maxa||a[x]<mina) return -1;
	b[x]=1;x=fa[x];
    }
    while(x!=y){
	if(a[x]>maxa||a[x]<mina) return -1;
	if(a[y]>maxa||a[y]<mina) return -1;
	b[x]=1;b[y]=1,
	    x=fa[x];y=fa[y];
    }
    b[x]=1;
    return x;
}
long long dfss(int x,int father);
int mul(long long &x,int xx,int yy){
    long long y=dfss(xx,yy);
    if(y==-1) return 0;
    y++;
    if(x==0) x++;
    x*=y;
    x%=P;
 //   printf("%lld %d %d %lld\n",x,xx,yy,y);
}
long long dfss(int x,int father){
    if(b[x]||a[x]>maxa||a[x]<mina) return -1;
    long long ansss=0,now=1;
    for(int i=first[x];i;i=nxt[i])
	if(go[i]!=father){
	    //mul(ansss,dfss(go[i],x));
	    mul(ansss,go[i],x);
	}
    //if(anss==1) return 0;
    return ansss;
}
int LCA(int x,int y){
    while(deep[x]>deep[y]){
	b[x]=0;
	//mul(anss,dfss(x,0ll));
	mul(anss,x,0);
	//anss=anss*dfss(x,0);
	anss%=P;
	b[x]=1;
	x=fa[x];
    }
    while(x!=y){
	b[x]=0;
	//mul(anss,dfss(x,0ll));
	mul(anss,x,0);
	//anss=anss*dfss(x,0);
	anss%=P;
	b[x]=1;

	b[y]=0;
	//mul(anss,dfss(y,0ll));
	mul(anss,y,0);
	//anss=anss*dfss(y,0);
	anss%=P;
	b[y]=1;

	x=fa[x];
	y=fa[y];
    }
    b[x]=0;
    //mul(anss,dfss(x,0ll));
    mul(anss,x,0);
    //anss=anss*dfss(x,0);
    anss%=P;
    b[x]=1;
}

int work(int x,int y){
   // printf("%d %d\n",x,y);
    memset(b,0,sizeof(b));
    maxa=a[x]; mina=a[y];
    if(deep[x]<deep[y]) swap(x,y);
    int father=lca(x,y);
    if(father==-1) return 0;
    anss=0;
    LCA(x,y);
    //printf("%lld ",anss);
    return anss;
}
int dfs(int x,int father){
    fa[x]=father;
    deep[x]=deep[father]+1;
    for(int i=first[x];i;i=nxt[i])
	if(go[i]!=father)
	    dfs(go[i],x);
}
int main(){
    freopen("lkf.in","r",stdin);
    freopen("lkf.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
	scanf("%d",&a[i]);
	q.push_back(make_pair(a[i],i));
    }
    sort(q.begin(),q.end());
    for(int i=1;i<n;i++){
	scanf("%d%d",&x,&y);
	add(x,y);
	add(y,x);
    }
    dfs(1,0);
    last=1;ans=0;
    for(int i=0;i<n;i++){
	while(q[last].first-q[i].first<m&&last<n) last++;
	if(last>n) break;
	if(q[last].first-q[i].first==m) ans=(ans+work(q[last].second,q[i].second))%P;
    }
    printf("%lld",ans);
}
