g++ -o a lkf.cpp -lm
./a
cat lkf.in
echo
diff lkf.out lkf.ans
