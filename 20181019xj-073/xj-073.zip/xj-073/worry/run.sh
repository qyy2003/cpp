g++ -o a worry.cpp -lm
./a
cat worry.in
echo
diff worry.ans worry.out
