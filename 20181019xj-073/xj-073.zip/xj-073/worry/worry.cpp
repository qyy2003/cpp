#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
const int MAXA=1e5+7;
int n,m,fa[MAXA],e[MAXA],x,y,z,deep[MAXA],ans[MAXA];
vector<pair<int,pair<int,int> >  >q; 
vector<pair<int,int> >go[MAXA];
int dfs(int x,int father){
    deep[x]=deep[father]+1;
    fa[x]=father;
    for(int i=0;i<go[x].size();i++)
	if(go[x][i].first!=father)
	    dfs(go[x][i].first,x),e[go[x][i].first]=go[x][i].second;
}

int lca(int x,int y,int z){
    if(deep[x]<deep[y]) swap(x,y);
    while(deep[x]>deep[y]) ans[e[x]]=z,x=fa[x];
    while(x!=y) ans[e[x]]=z,ans[e[y]]=z,x=fa[x],y=fa[y];
    return x;
}

int main(){
    freopen("worry.in","r",stdin);
    freopen("worry.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<n;i++){
	scanf("%d%d",&x,&y);
	go[x].push_back(make_pair(y,i));
	go[y].push_back(make_pair(x,i));
    }
    dfs(1,0);
    for(int i=0;i<m;i++){
	scanf("%d%d%d",&x,&y,&z);
	q.push_back(make_pair(-z,make_pair(x,y)));
    }
    sort(q.begin(),q.end());
    memset(ans,-1,sizeof(ans));
    for(int i=0;i<m;i++)lca(q[i].second.first,q[i].second.second,-q[i].first);
    for(int i=1;i<n;i++)printf("%d\n",ans[i]);
}
